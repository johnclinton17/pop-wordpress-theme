<?php

/**
 * Silence is golden.
 */
